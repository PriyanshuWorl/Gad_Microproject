﻿Public Class Form4
    Public Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        TextBox2.PasswordChar = "*"
    End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim UserName As String
        Dim Password As String
        Dim C As New Form1
        UserName = "Priyanshu"
        Password = "12345"

        If TextBox1.Text = "Priyanshu" And TextBox2.Text = "12345" Then
            C.Show()
            Me.Hide()
        Else
            ErrorProvider1.SetError(TextBox2, "Password Is Wrong")
        End If
    End Sub
End Class