﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.course_Lab = New System.Windows.Forms.Label()
        Me.Year_Lab = New System.Windows.Forms.Label()
        Me.First_Lab = New System.Windows.Forms.Label()
        Me.Middle_Lab = New System.Windows.Forms.Label()
        Me.Last_Lab = New System.Windows.Forms.Label()
        Me.Address_Lab = New System.Windows.Forms.Label()
        Me.Phone_Lab = New System.Windows.Forms.Label()
        Me.JoinDate_Lab = New System.Windows.Forms.Label()
        Me.Roll_Lab = New System.Windows.Forms.Label()
        Me.BirthDate_Lab = New System.Windows.Forms.Label()
        Me.Cast_Lab = New System.Windows.Forms.Label()
        Me.Income_Lab = New System.Windows.Forms.Label()
        Me.Gender_Lab = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(757, 87)
        Me.Panel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 19)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Course"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 148)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 19)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Year"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 190)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 19)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "First Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 229)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(101, 19)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Middle Name"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 268)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 19)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Last Name"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 310)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(102, 19)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Local Address"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(13, 355)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 19)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Phone No"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(13, 398)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 19)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Gender"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(390, 103)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(72, 19)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Join Date"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(390, 148)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(59, 19)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Roll No"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(390, 190)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(97, 19)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Date of Birth"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(390, 229)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 19)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Cast"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(388, 268)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(112, 19)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "Annual Income"
        '
        'course_Lab
        '
        Me.course_Lab.AutoSize = True
        Me.course_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.course_Lab.Location = New System.Drawing.Point(74, 103)
        Me.course_Lab.Name = "course_Lab"
        Me.course_Lab.Size = New System.Drawing.Size(60, 19)
        Me.course_Lab.TabIndex = 14
        Me.course_Lab.Text = "Label14"
        '
        'Year_Lab
        '
        Me.Year_Lab.AutoSize = True
        Me.Year_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Year_Lab.Location = New System.Drawing.Point(57, 151)
        Me.Year_Lab.Name = "Year_Lab"
        Me.Year_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Year_Lab.TabIndex = 15
        Me.Year_Lab.Text = "Label14"
        '
        'First_Lab
        '
        Me.First_Lab.AutoSize = True
        Me.First_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.First_Lab.Location = New System.Drawing.Point(100, 190)
        Me.First_Lab.Name = "First_Lab"
        Me.First_Lab.Size = New System.Drawing.Size(60, 19)
        Me.First_Lab.TabIndex = 16
        Me.First_Lab.Text = "Label15"
        '
        'Middle_Lab
        '
        Me.Middle_Lab.AutoSize = True
        Me.Middle_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Middle_Lab.Location = New System.Drawing.Point(120, 229)
        Me.Middle_Lab.Name = "Middle_Lab"
        Me.Middle_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Middle_Lab.TabIndex = 17
        Me.Middle_Lab.Text = "Label16"
        '
        'Last_Lab
        '
        Me.Last_Lab.AutoSize = True
        Me.Last_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Last_Lab.Location = New System.Drawing.Point(99, 268)
        Me.Last_Lab.Name = "Last_Lab"
        Me.Last_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Last_Lab.TabIndex = 18
        Me.Last_Lab.Text = "Label17"
        '
        'Address_Lab
        '
        Me.Address_Lab.AutoSize = True
        Me.Address_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Address_Lab.Location = New System.Drawing.Point(121, 310)
        Me.Address_Lab.Name = "Address_Lab"
        Me.Address_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Address_Lab.TabIndex = 19
        Me.Address_Lab.Text = "Label18"
        '
        'Phone_Lab
        '
        Me.Phone_Lab.AutoSize = True
        Me.Phone_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Phone_Lab.Location = New System.Drawing.Point(96, 355)
        Me.Phone_Lab.Name = "Phone_Lab"
        Me.Phone_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Phone_Lab.TabIndex = 20
        Me.Phone_Lab.Text = "Label19"
        '
        'JoinDate_Lab
        '
        Me.JoinDate_Lab.AutoSize = True
        Me.JoinDate_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.JoinDate_Lab.Location = New System.Drawing.Point(468, 103)
        Me.JoinDate_Lab.Name = "JoinDate_Lab"
        Me.JoinDate_Lab.Size = New System.Drawing.Size(60, 19)
        Me.JoinDate_Lab.TabIndex = 21
        Me.JoinDate_Lab.Text = "Label20"
        '
        'Roll_Lab
        '
        Me.Roll_Lab.AutoSize = True
        Me.Roll_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Roll_Lab.Location = New System.Drawing.Point(455, 148)
        Me.Roll_Lab.Name = "Roll_Lab"
        Me.Roll_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Roll_Lab.TabIndex = 22
        Me.Roll_Lab.Text = "Label21"
        '
        'BirthDate_Lab
        '
        Me.BirthDate_Lab.AutoSize = True
        Me.BirthDate_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.BirthDate_Lab.Location = New System.Drawing.Point(493, 190)
        Me.BirthDate_Lab.Name = "BirthDate_Lab"
        Me.BirthDate_Lab.Size = New System.Drawing.Size(60, 19)
        Me.BirthDate_Lab.TabIndex = 23
        Me.BirthDate_Lab.Text = "Label22"
        '
        'Cast_Lab
        '
        Me.Cast_Lab.AutoSize = True
        Me.Cast_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Cast_Lab.Location = New System.Drawing.Point(433, 229)
        Me.Cast_Lab.Name = "Cast_Lab"
        Me.Cast_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Cast_Lab.TabIndex = 24
        Me.Cast_Lab.Text = "Label23"
        '
        'Income_Lab
        '
        Me.Income_Lab.AutoSize = True
        Me.Income_Lab.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Income_Lab.Location = New System.Drawing.Point(506, 268)
        Me.Income_Lab.Name = "Income_Lab"
        Me.Income_Lab.Size = New System.Drawing.Size(60, 19)
        Me.Income_Lab.TabIndex = 25
        Me.Income_Lab.Text = "Label24"
        '
        'Gender_Lab
        '
        Me.Gender_Lab.AutoSize = True
        Me.Gender_Lab.Location = New System.Drawing.Point(78, 398)
        Me.Gender_Lab.Name = "Gender_Lab"
        Me.Gender_Lab.Size = New System.Drawing.Size(91, 19)
        Me.Gender_Lab.TabIndex = 26
        Me.Gender_Lab.Text = "Gender_Lab"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(755, 426)
        Me.Controls.Add(Me.Gender_Lab)
        Me.Controls.Add(Me.Income_Lab)
        Me.Controls.Add(Me.Cast_Lab)
        Me.Controls.Add(Me.BirthDate_Lab)
        Me.Controls.Add(Me.Roll_Lab)
        Me.Controls.Add(Me.JoinDate_Lab)
        Me.Controls.Add(Me.Phone_Lab)
        Me.Controls.Add(Me.Address_Lab)
        Me.Controls.Add(Me.Last_Lab)
        Me.Controls.Add(Me.Middle_Lab)
        Me.Controls.Add(Me.First_Lab)
        Me.Controls.Add(Me.Year_Lab)
        Me.Controls.Add(Me.course_Lab)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Name = "Form3"
        Me.Text = "Label14"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents course_Lab As Label
    Friend WithEvents Year_Lab As Label
    Friend WithEvents First_Lab As Label
    Friend WithEvents Middle_Lab As Label
    Friend WithEvents Last_Lab As Label
    Friend WithEvents Address_Lab As Label
    Friend WithEvents Phone_Lab As Label
    Friend WithEvents JoinDate_Lab As Label
    Friend WithEvents Roll_Lab As Label
    Friend WithEvents BirthDate_Lab As Label
    Friend WithEvents Cast_Lab As Label
    Friend WithEvents Income_Lab As Label
    Friend WithEvents Gender_Lab As Label
End Class
