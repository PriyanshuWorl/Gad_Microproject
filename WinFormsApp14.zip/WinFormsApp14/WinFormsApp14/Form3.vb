﻿Public Class Form3

    Public Property Course As String
    Public Property Year As String
    Public Property First_name As String
    Public Property Middle_name As String
    Public Property Last_name As String
    Public Property Local_address As String
    Public Property Phone_No As String
    Public Property Gender As String
    ''Public Property Join_dateAs String
    Public Property Roll_no As String
    ''Public Property DateOfBirth As String
    Public Property Cast As String
    Public Property Income As String




    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        course_Lab.Text = Course
        Year_Lab.Text = Year
        First_Lab.Text = First_name
        Middle_Lab.Text = Middle_name
        Last_Lab.Text = Last_name
        Address_Lab.Text = Local_address
        Phone_Lab.Text = Phone_No
        Gender_Lab.Text = Gender
        Roll_Lab.Text = Roll_no
        Cast_Lab.Text = Cast
        Income_Lab.Text = Income
    End Sub
End Class